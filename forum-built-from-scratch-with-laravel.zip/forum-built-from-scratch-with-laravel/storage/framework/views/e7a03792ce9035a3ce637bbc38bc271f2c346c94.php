<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 mb-2">
                <div class="mb-5 mt-3 d-flex" style="justify-content: space-evenly;">
                        <a href="<?php echo e(url('/forum?filter=all')); ?>" class="btn btn-info">Ver Todo</a>
                        <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/forum?filter=me')); ?>"  class="btn btn-info">Mis Hilos</a>
                        <?php endif; ?>
                        <a href="<?php echo e(url('/forum?filter=sloved')); ?>"  class="btn btn-info">Temas Removidos</a>
                        <a href="<?php echo e(url('/forum?filter=notsloved')); ?>"  class="btn btn-info">Posts Abiertos</a>
                        <a href="<?php echo e(url('/forum?filter=new')); ?>"  class="btn btn-info">Nuevos Hilos</a>
                        <a href="<?php echo e(url('/forum?filter=old')); ?>"  class="btn btn-info">Temas Antiguos</a>
                </div>
                <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card shadow-lg">
                    <div class="card-header bg-secondary text-white d-flex">
                        <div class="">
                        Iniciado por : <img src="" width="50px" height="50px" alt="">
                        <?php echo e($thread->user->name); ?></div>
                        <div class="ml-auto">
                            <a href="<?php echo e(route('show_thread_id',$thread->slug)); ?>" class="badge badge-warning">ver</a>
                            <?php if(Auth::id() == $thread->user_id): ?>
                            <a href="<?php echo e(route('edit_thread',$thread->id)); ?>" class="badge badge-success">editar</a>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="card-body">
                        <p><?php echo Markdown::convertToHtml($thread->content); ?></p>
                    </div>
                        <div class="card-footer text-muted d-flex">

                            <div class="">
                                <?php echo e($thread->created_at->diffForHumans()); ?>

                            </div>

                            <div class="ml-auto">
                                <?php if($thread->hasclosed()): ?>
                                <span class="badge badge-danger">cerrado</span>
                                <?php else: ?>
                                <span class="badge badge-info">abierto</span>
                                <?php endif; ?>
                            </div>

                        </div>
                </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($threads->links()); ?>

            </div>
            <div class="col-md-2">
                <?php echo $__env->make('inc.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>