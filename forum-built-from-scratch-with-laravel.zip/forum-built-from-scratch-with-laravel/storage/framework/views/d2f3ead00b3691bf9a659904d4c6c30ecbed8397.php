<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
<div class="col-md-8 bg-white pt-4 pb-4 shadow-lg">
    <?php echo $__env->make('inc.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="form">
<form action="<?php echo e(route('new_channel')); ?>" method="post">
    <?php echo csrf_field(); ?>
<div class="row">
<div class="col-sm-8">
    <div class="form-group">
            <input type="text" name="title" class="form-control" placeholder="Título de la asignatura">
        </div>
</div>
<div class="col-sm-4">
<button  class="btn btn-outline-danger" type="submit">Agregar categoría</button>
</div>
</div>
</form>
</div>
<div class="col-md-12">
<div class="table-responsive">
    <table class="table">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">Asignatura</th>
        <?php if(Auth::user()->role): ?>
        <th scope="col">Editar</th>
        <th scope="col">Borrar</th>
        <?php endif; ?>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = App\Channel::paginate(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($channel->id); ?></td>
            <td>
                    <div class="form-group col-sm-10">
                        <input type="text" name="title" value="<?php echo e($channel->title); ?>" disabled class="form-control">
                    </div>
                    <?php if(Auth::user()->role): ?>
                    <td>
                    <a class="badge badge-success" href="<?php echo e(route('edit_channel',$channel->id)); ?>">editar</a>
                    </td>
                    <?php endif; ?>
                </form>
            </td>
            <?php if(Auth::user()->role): ?>
            <td>
                <form action="<?php echo e(route('delete_channel',$channel->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                        <button onclick="return confirm('Estás seguro que quieres eliminar?');" class="badge badge-danger" type="submit">Basura</button>
                </form>
            </td>
            <?php endif; ?>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
</div>
</div>
<div class="col-md-4 ">
<div class=" shadow-lg">
<?php echo $__env->make('inc.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>