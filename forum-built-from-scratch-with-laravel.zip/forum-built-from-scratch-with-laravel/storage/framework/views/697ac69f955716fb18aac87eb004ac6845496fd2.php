
<?php if(auth()->guard()->check()): ?>
<ul class="list-group">
    <li class="list-group-item d-flex justify-content-between align-items-center">
        <a href="<?php echo e(route('home')); ?>" >Dashboard</a>
    </li>
<?php endif; ?>

    <li class="list-group-item d-flex justify-content-between align-items-center">
        <a href="http://www.inf.unap.cl/index.php/category/noticias/" >Ir a Página Web ICCI Unap</a>

    </li>
    <?php if(auth()->guard()->check()): ?>

    <li class="list-group-item d-flex justify-content-between align-items-center">
        <a href="<?php echo e(route('my_profile')); ?>" >Mi perfil</a>
    </li>

    <?php if(Auth::user()->role): ?>
    <li class="list-group-item d-flex justify-content-between align-items-center">
        <a  href="#" data-toggle="collapse" data-target="#collapseOne" aria-controls="collapseOne" aria-expanded="false">Usuarios</a>
        <span class="badge badge-success badge-pill"><?php echo e(App\User::all()->count()); ?></span>

    </li>
    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
        <li class="list-group-item d-flex justify-content-between align-items-center list-group-item-dark">
            <a href="<?php echo e(route('new_user_create')); ?>" >Nuevo Usuario</a>
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-center list-group-item-dark">
            <a href="<?php echo e(route('show_all_users')); ?>">Todos los Usuarios</a>
        </li>
    </div>
    <?php endif; ?>
    <?php if(Auth::user()->role): ?>
    <li class="list-group-item d-flex justify-content-between align-items-center">
            <a href="<?php echo e(route('create_channel')); ?>">Asignaturas</a>
    <span class="badge badge-danger badge-pill"><?php echo e(App\Channel::all()->count()); ?></span>
    </li>
    <?php endif; ?>

    <li class="list-group-item d-flex justify-content-between align-items-center">
        <a href="#"  data-toggle="collapse" data-target="#collapse2" aria-controls="collapse2" aria-expanded="false">Temas</a>
        <span class="badge badge-info badge-pill"><?php echo e(App\Thread::all()->count()); ?></span>
    </li>
    <div id="collapse2" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
        <li class="list-group-item d-flex justify-content-between align-items-center list-group-item-dark">
            <a href="<?php echo e(route('create_thread')); ?>">Nuevo Tema</a>
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-center list-group-item-dark">
            <a href="<?php echo e(route('show_all_threads')); ?>">Todos los Temas</a>
        </li>
    </div>
<?php endif; ?>
