<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <div class="col-md-8 bg-white pt-4 pb-4 shadow-lg">
        <?php echo $__env->make('inc.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="form">
    <form action="<?php echo e(route('update_channel',$channel->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
    <div class="row">
    <div class="col-sm-8">
        <div class="form-group">
                <input type="text" name="title" class="form-control" value="<?php echo e($channel->title); ?>">
            </div>
    </div>
    <div class="col-sm-4">
    <button  class="btn btn-outline-danger" type="submit">Actualizar</button>
    </div>
    </div>
    </form>
    </div>
     </div>
<div class="col-md-4 ">
<div class=" shadow-lg">
<?php echo $__env->make('inc.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>