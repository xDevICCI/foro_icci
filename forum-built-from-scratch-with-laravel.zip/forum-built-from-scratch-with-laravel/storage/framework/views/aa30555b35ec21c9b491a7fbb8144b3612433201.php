<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 mb-2">
                <div class="card shadow-lg">
                    <div class="card-header bg-dark text-white d-flex">
                        <div class="">
                        Iniciado por : <?php echo e($thread->user->name); ?>

                        </div>
                        <div class="ml-auto">


                        </div>
                    </div>
                    <div class="card-body">
                        <p><?php echo Markdown::convertToHtml($thread->content); ?></p>
                        <br>
                                <?php if($bestanswer): ?>
                                <div class="card text-white bg-info mb-3">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <span style="text-decoration-line: underline">Mejor respuesta por :</span> <?php echo e($bestanswer->user->name); ?>

                                            ( <?php echo e($bestanswer->user->points); ?> <i class="fas fa-dollar-sign"></i> )
                                        </h5>

                                        <h5 class="card-title"><?php echo e($bestanswer->title); ?></h5>
                                        <p class="card-text">
                                            <?php echo e($bestanswer->content); ?>

                                        </p>
                                    </div>
                                </div>
                                <?php endif; ?>
                    </div>
                    <div class="card-footer text-muted">
                        <?php echo e($thread->created_at->diffForHumans()); ?>

                    </div>
                </div>

                <br>

        <?php $__currentLoopData = $thread->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card shadow-lg">
            <div class="card-header bg-secondary text-white ">
               <div class="d-flex">
                   <div class="">
                       <?php echo e($reply->user->name); ?> ( <?php echo e($reply->user->points); ?> <i class="fas fa-dollar-sign"></i> )
                   </div>
                   <div class="ml-auto" style="display: inline-flex">
                       <?php if(Auth::id() == $reply->user_id): ?>
                           
                           
                       <?php if(!$reply->best_answer): ?>

                               <a href="<?php echo e(route('edit_reply',$reply)); ?>"><i class="far fa-edit text-white"></i></a>&nbsp;

                               <a href="<?php echo e(route('edit_reply',$reply)); ?>"><i class="fas fa-trash"></i></a> &nbsp;

                           <?php endif; ?>
                       <?php endif; ?>
                   <?php if(auth()->guard()->check()): ?>
                       <?php if(Auth::id() == $thread->user->id): ?>
                       
                       <?php if(!$bestanswer): ?>
                       <form action="<?php echo e(route('make_best_answer',$reply->id)); ?>" method="post">
                           <?php echo csrf_field(); ?>
                           <button type="submit" class="btn btn-info btn-sm">Like como mejor respuesta</button>
                       </form>

                       <?php endif; ?>
                       <?php endif; ?>
                       <?php endif; ?>

                   </div>
               </div>
            </div>
            <div class="card-body">
                <p><?php echo Markdown::convertToHtml($reply->content); ?></p>
            </div>
            <div class="card-footer text-muted">
                <?php echo e($reply->created_at->diffForHumans()); ?>

            </div>
            </div>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if(auth()->guard()->check()): ?>
                <div class="bg-white pt-4 pb-4 pl-3 pr-3 shadow-lg">
                    <?php echo $__env->make('inc.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <form action="<?php echo e(route('post_reply',$thread->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group">
                                    <input type="text" name="title" class="form-control" placeholder="title of your reply ...">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-outline-primary btn-block" type="submit">Seguir</button>
                            </div>

                        </div>

                        <div class="row pt-4 pb-4 pl-1 pr-1">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <textarea name="content" class="form-control" id="" cols="30" rows="10" placeholder="Tu solución..."></textarea>
                                </div>
                            </div>

                        </div>

                    </form>
                </div>
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>
<div class="bg-white pt-4 pb-4 pl-3 pr-3 shadow-lg">
    <h5 class="text-center">Por favor <a href="<?php echo e(route('login')); ?>">, inicia sesión</a> o <a href="<?php echo e(route('register')); ?>">Registrate</a></h5>
</div>
<?php endif; ?>
            </div>

            <div class="col-md-4">
                <div class="shadow-lg">
                    <?php echo $__env->make('inc.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>