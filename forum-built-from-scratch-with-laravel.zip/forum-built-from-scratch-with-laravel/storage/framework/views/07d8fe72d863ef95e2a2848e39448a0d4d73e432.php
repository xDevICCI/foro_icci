<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 mb-2">
                <div class="shadow-lg bg-white pt-3 pb-3 ">

                    <div class="col-md-12">
                        <?php echo $__env->make('inc.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo e(Form::open(['route'=>['update_thread',$thread->id],'method'=>'post'])); ?>

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group"><input value="<?php echo e($thread->title); ?>" type="text" class="form-control" placeholder="title" name="title"></div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <select name="channel_id" id="channelid" class="form-control">
                                        <?php $__currentLoopData = App\Channel::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <option value="<?php echo e($channel->id); ?>"
                                            <?php if($channel->id == $thread->channel->id): ?>
                                                selected
                                                    <?php endif; ?>
                                            ><?php echo e($channel->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <textarea name="content"  class="form-control" id="" cols="30" rows="10"><?php echo e($thread->content); ?></textarea>
                            </div>
                            <button class="btn btn-outline-info mt-3 ml-3" type="submit">Actualizar</button>
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>



                </div>
            </div>
            <div class="col-md-4 shadow-lg">
                <?php echo $__env->make('inc.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>