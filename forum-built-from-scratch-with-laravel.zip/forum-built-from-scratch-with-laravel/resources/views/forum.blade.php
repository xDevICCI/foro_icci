@extends('layouts.app')



@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 mb-2">
                <div class="mb-5 mt-3 d-flex" style="justify-content: space-evenly;">
                        <a href="{{ url('/forum?filter=all') }}" class="btn btn-info">Ver Todo</a>
                        @auth
                        <a href="{{ url('/forum?filter=me') }}"  class="btn btn-info">Mis Hilos</a>
                        @endauth
                        <a href="{{ url('/forum?filter=sloved') }}"  class="btn btn-info">Temas Removidos</a>
                        <a href="{{ url('/forum?filter=notsloved') }}"  class="btn btn-info">Posts Abiertos</a>
                        <a href="{{ url('/forum?filter=new') }}"  class="btn btn-info">Nuevos Hilos</a>
                        <a href="{{ url('/forum?filter=old') }}"  class="btn btn-info">Temas Antiguos</a>
                </div>
                @foreach($threads as $thread)

                    <div class="card shadow-lg">
                    <div class="card-header bg-secondary text-white d-flex">
                        <div class="">
                        Iniciado por : <img src="" width="50px" height="50px" alt="">
                        {{ $thread->user->name }}</div>
                        <div class="ml-auto">
                            <a href="{{ route('show_thread_id',$thread->slug) }}" class="badge badge-warning">ver</a>
                            @if(Auth::id() == $thread->user_id)
                            <a href="{{ route('edit_thread',$thread->id) }}" class="badge badge-success">editar</a>
                            @endauth
                        </div>
                    </div>

                    <div class="card-body">
                        <p>{!!  Markdown::convertToHtml($thread->content) !!}</p>
                    </div>
                        <div class="card-footer text-muted d-flex">

                            <div class="">
                                {{ $thread->created_at->diffForHumans() }}
                            </div>

                            <div class="ml-auto">
                                @if($thread->hasclosed())
                                <span class="badge badge-danger">cerrado</span>
                                @else
                                <span class="badge badge-info">abierto</span>
                                @endif
                            </div>

                        </div>
                </div>
                    <br>
                @endforeach
                {{ $threads->links() }}
            </div>
            <div class="col-md-2">
                @include('inc.sidebar')
            </div>

        </div>
    </div>
@endsection
