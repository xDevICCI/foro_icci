## just another forum 

![user](https://github.com/almokhtarbr/forum2/blob/master/forum%20scrrenshoot/user%20ui.png)
![users](https://github.com/almokhtarbr/forum2/blob/master/forum%20scrrenshoot/users.png)
![admin](https://github.com/almokhtarbr/forum2/blob/master/forum%20scrrenshoot/admin.png)
![channels](https://github.com/almokhtarbr/forum2/blob/master/forum%20scrrenshoot/channels.png)
![profile](https://github.com/almokhtarbr/forum2/blob/master/forum%20scrrenshoot/edit_profile.png)
![p2](https://github.com/almokhtarbr/forum2/blob/master/forum%20scrrenshoot/profile.png)
![new](https://github.com/almokhtarbr/forum2/blob/master/forum%20scrrenshoot/new_user.png)
![index](https://github.com/almokhtarbr/forum2/blob/master/forum%20scrrenshoot/index.png)



> you can use it if you like it :grinning:
